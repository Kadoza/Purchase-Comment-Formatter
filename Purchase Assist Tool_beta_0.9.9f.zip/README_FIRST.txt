~INSTRUCTIONS~
Unzip this directory into your Documents folder. You can create a shortcut to the EXE file to place on your desktop or wherever you prefer.

When you first run the tool, it will create a text file in its directory called 'agent_info.txt'. It saves your input for AGENT NAME, AGENT EMAIL, and AGENT TEAM here. This makes it so that you don't have to fill that part in every time you run it.

Please report any bugs or formatting errors to Kraig Clubb.


~CHANGELOG~
0.9.9f
 - CHANGED the PoC information for Dell Technologies to our new and current representative.

0.9.9e
 - FIXED an issue where if the AGENT NAME and AGENT EMAIL variable matched any names in the TAC Point of Contact section of the finalized text, it would result in duplicated names. It now ignores the AGENT NAME and AGENT EMAIL fields if they are found within that section.
 - ADDED support for two common vendors used by Network Operations.

0.9.9d
 - FIXED the vendor selection box not defaulting to 'Other' as the vendor instead of 
	'#-~'ERROR: NO VENDOR SELECTED'~-#' when not edited.

0.9.9c
 - FIXED the 'Lock Fields' checkbox not unlocking fields when unchecked
 - ADDED stop codes for required fields if they are left blank
 - Reformatted error parsing in the finalized text to make it more noticeable.

0.9.9b
 - FIXED "Quote Number:" showing up if the finalized text is finalized twice and there is no Quote involved.